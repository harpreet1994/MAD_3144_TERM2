
<?php
$A1 = $_POST['n1'];
$A2 = $_POST['n2'];
echo "<div>";
for($i = $A1; $i <=$A2; $i++)
{
	if ($i==2  $i==3 $i==7 $i==9){
		echo "$i";
	}
	else if (($i%2)!= 0 && ($i%3)!=0 && ($i%5) !0 && ($i%7) != 0)
	{
		echo "$i";
	}
	else
		continue;
}
echo "these3 are prime number between $A1 and $A2.";
echo "</div>";
?> 