<?php 

$number1 = $_POST['number1'];
$number2 = $_POST['number2'];
$number3 = $_POST['number3'];
//calculate three numbers

$sum = $number1+$number2+$number3;
$average = ($number1+$number2+$number3)/3;
?>

<!DOCTYPE html>
<html>
<head>
<title> Calculation of three numbers</title>
<link rel = "stylesheet" type = "text/css" href = "main.css">
</head>
<body>
<main>
<h1> Number Calculator</h1>
<label>sum:</label>
<span> <?php echo $sum_formatted; ?></span><br>
<label>average:</label>
<span><?php echo $average_escaped; ?></span><br>
<label>highest:</label>
<span><?php echo $highest_escaped; ?></span><br></main>
</body>
</html>